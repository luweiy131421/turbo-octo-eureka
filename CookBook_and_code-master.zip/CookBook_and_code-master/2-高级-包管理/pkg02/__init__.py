
__all__=['p01']

def inInit():
    print("I am in inti of pacakge")