from p01 import *


sayHello()

stu = Student("yaona", 28)
stu.say()