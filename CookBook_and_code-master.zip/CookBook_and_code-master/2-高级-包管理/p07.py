import pkg01

pkg01.inInit()

