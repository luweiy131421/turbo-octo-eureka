from django.apps import AppConfig


class MytplConfig(AppConfig):
    name = 'mytpl'
